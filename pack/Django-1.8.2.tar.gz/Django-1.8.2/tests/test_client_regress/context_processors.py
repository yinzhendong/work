def special(request):
    return {'path': request.special_path}
