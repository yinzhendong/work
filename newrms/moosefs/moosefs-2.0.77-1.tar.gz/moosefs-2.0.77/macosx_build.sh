#!/usr/bin/env bash

./configure --prefix=/usr --sysconfdir=/private/etc
make
